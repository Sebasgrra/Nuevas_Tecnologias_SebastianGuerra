const Title = () => {
    return (
        <h1 className="text-5xl font-anton font-bold tracking-wides">
            Escriba las tareas que tiene que realizar proximamente
        </h1>
    );
}


export { Title }